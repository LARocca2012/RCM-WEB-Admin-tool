<?php

echo "EDIT ONLY zzz_add_here_server_configurations.php FILE, ITS BETA VERSION!";
?>
